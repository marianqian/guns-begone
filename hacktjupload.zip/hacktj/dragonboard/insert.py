
f = open('info.txt', 'w+')
f.write(input('Enter Serial number of gun: ')+'\n')
f.write(input('Enter your name: ')+'\n')
f.write(input('Enter your age: ')+'\n')
f.write(input('Enter your gender (0 for male; 1 for female): ')+'\n')
f.write(input('Enter your address: ') + '\n')
f.close()
