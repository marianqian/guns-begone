
from pastebin import PastebinAPI
f = open('latlng.txt', 'r')
f1 = f.readlines()
for x in f1:
    print(x)
